from sqlalchemy import desc
from sqlalchemy.orm import Session

from app.auth import hash_password
from app.models import DiagnosisReport, User
from app.schemas import ModuleCDiagnosisInput, UserCreate


def get_user_by_username(db: Session, username: str) -> User | None:
    return db.query(User).filter(User.username == username).first()


def create_user(db: Session, user_in: UserCreate) -> User:
    user = User(
        username=user_in.username,
        email=user_in.email,
        full_name=user_in.full_name,
        role=user_in.role,
        hashed_password=hash_password(user_in.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def ensure_seed_admin(db: Session, username: str, email: str, password: str) -> None:
    """Idempotently create a default admin account so the API is usable on first boot."""
    if get_user_by_username(db, username) is not None:
        return
    db.add(
        User(
            username=username,
            email=email,
            full_name="Seed Admin",
            role="admin",
            hashed_password=hash_password(password),
        )
    )
    db.commit()


def save_diagnosis_report(
    db: Session,
    diagnosis: ModuleCDiagnosisInput,
    generated_report: str,
    report_source: str,
    created_by_id: str | None,
) -> DiagnosisReport:
    top = diagnosis.top_prediction()
    record = DiagnosisReport(
        patient_id=diagnosis.patient_id,
        study_id=diagnosis.study_id,
        image_filename=diagnosis.image_filename,
        model_version=diagnosis.model_version,
        predictions_json=[p.model_dump() for p in diagnosis.predictions],
        clinical_note=diagnosis.clinical_note,
        gradcam_summary=diagnosis.gradcam_summary,
        top_label=top.label,
        top_probability=top.probability,
        generated_report=generated_report,
        report_source=report_source,
        created_by_id=created_by_id,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def get_report(db: Session, report_id: str) -> DiagnosisReport | None:
    return db.query(DiagnosisReport).filter(DiagnosisReport.id == report_id).first()


def list_reports(
    db: Session, patient_id: str | None = None, skip: int = 0, limit: int = 50
) -> list[DiagnosisReport]:
    query = db.query(DiagnosisReport)
    if patient_id:
        query = query.filter(DiagnosisReport.patient_id == patient_id)
    return query.order_by(desc(DiagnosisReport.created_at)).offset(skip).limit(limit).all()
