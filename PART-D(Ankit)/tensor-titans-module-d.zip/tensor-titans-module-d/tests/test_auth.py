def test_health_ok(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_register_and_login(client):
    resp = client.post(
        "/auth/register",
        json={
            "username": "newdoc",
            "email": "newdoc@example.com",
            "password": "supersecret",
            "full_name": "Dr. New",
        },
    )
    assert resp.status_code == 201
    assert resp.json()["username"] == "newdoc"

    resp = client.post("/auth/login", data={"username": "newdoc", "password": "supersecret"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["token_type"] == "bearer"
    assert body["access_token"]


def test_duplicate_registration_rejected(client):
    payload = {
        "username": "dupe",
        "email": "dupe@example.com",
        "password": "supersecret",
    }
    assert client.post("/auth/register", json=payload).status_code == 201
    assert client.post("/auth/register", json=payload).status_code == 409


def test_wrong_password_rejected(client):
    client.post(
        "/auth/register",
        json={"username": "guard", "email": "guard@example.com", "password": "correcthorse"},
    )
    resp = client.post("/auth/login", data={"username": "guard", "password": "wrong"})
    assert resp.status_code == 401


def test_protected_route_requires_token(client):
    resp = client.get("/reports/")
    assert resp.status_code == 401


def test_protected_route_with_token(client, auth_headers):
    resp = client.get("/reports/", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json() == []
