# Tensor Titans — Module D
### AI Report Generation & Production Deployment

This is Part D of the *Multi-Modal Medical Image Analysis Platform*: it turns a
diagnosis payload (from Module C) into a structured radiology report using
**LangChain + Gemini**, permanently audit-logs every request to **PostgreSQL**,
and exposes it all through a **JWT-protected FastAPI** service that's ready to
containerize with **Docker** and ship via **GitHub Actions → Railway**.

```
AI Diagnosis Input → LangChain + Gemini Report → PostgreSQL Audit Logging
                    → JWT Guarded Gateway → Secure Cloud Deployment
```

## Status

- ✅ FastAPI service, JWT auth, PostgreSQL audit log, LangChain + Gemini report
  generation, Docker, docker-compose, GitHub Actions CI/CD, Railway config —
  all implemented and tested (11/11 tests passing).
- 🔌 **Mocked, not missing:** Module C's real model isn't wired in yet, since
  that's a teammate's deliverable. `app/module_c_client.py` ships a
  `MockModuleCClient` that returns realistically-shaped output so the whole
  pipeline already runs end-to-end today. See **"Connecting the real Module
  C"** below — it's a one-file swap.
- 🔑 **Gemini key optional for development:** if `GEMINI_API_KEY` isn't set,
  report generation automatically falls back to a deterministic local
  template (see `app/report_generator.py`), so you can demo and test the
  full pipeline without a live key. Set the key to get real Gemini-authored
  reports.

## Quickstart (Docker, recommended)

```bash
cp .env.example .env
# edit .env: at minimum set JWT_SECRET_KEY; add GEMINI_API_KEY when you have one
docker compose up --build
```

The API is now at `http://localhost:8000` (interactive docs at `/docs`). A
seed account is created automatically from `SEED_ADMIN_USERNAME` /
`SEED_ADMIN_PASSWORD` in `.env` (defaults to `admin` / `admin123` — change
this before deploying anywhere real).

## Quickstart (local Python, no Docker)

```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env                                  # DATABASE_URL defaults to sqlite for this path — see below
uvicorn app.main:app --reload
```

For local runs without Postgres installed, just point `DATABASE_URL` in
`.env` at `sqlite:///./dev.db` — every model uses portable SQLAlchemy types,
so SQLite works fine for development.

## Running the tests

```bash
pytest -q
```

Tests run against an isolated in-memory-style SQLite DB and never call the
real Gemini API (`GEMINI_API_KEY` is forced empty in `tests/conftest.py`), so
they run offline and in CI with no external dependencies.

## API overview

All endpoints are documented interactively at `/docs` (Swagger) once running.

| Method | Path                            | Auth | Purpose |
|--------|----------------------------------|------|---------|
| GET    | `/health`                        | none | Liveness/readiness probe (used by Docker & Railway) |
| POST   | `/auth/register`                 | none | Create a radiologist/clinician account |
| POST   | `/auth/login`                    | none | OAuth2 password flow → JWT access token |
| POST   | `/reports/generate`              | JWT  | **Main endpoint.** Accepts a `ModuleCDiagnosisInput` payload, generates a report, audit-logs it |
| POST   | `/reports/demo-generate/{patient_id}` | JWT | Same as above but runs the mock Module C client first — useful for demos before the real model is connected |
| GET    | `/reports/{id}`                  | JWT  | Fetch one generated report |
| GET    | `/reports/`                      | JWT  | List reports (the audit log), filterable by `patient_id` |

Example: log in, then generate a report from a raw diagnosis payload.

```bash
TOKEN=$(curl -s -X POST localhost:8000/auth/login \
  -d "username=admin&password=admin123" | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")

curl -X POST localhost:8000/reports/generate \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{
        "patient_id": "PT-0001",
        "clinical_note": "58-year-old male, productive cough and fever for 4 days.",
        "predictions": [
          {"label": "Pneumonia", "probability": 0.87},
          {"label": "Infiltration", "probability": 0.41}
        ],
        "gradcam_summary": "High activation in the right lower lobe."
      }'
```

## Connecting the real Module C

Everything Module D needs from Module C is defined in **one place**:
`ModuleCDiagnosisInput` in `app/schemas.py`. It matches what Module C's
notes describe (DenseNet-121 + ClinicalBERT fusion, 14-class multi-label
ChestX-ray14 prediction, Grad-CAM explainability):

```python
class ModuleCDiagnosisInput(BaseModel):
    patient_id: str
    study_id: str | None
    image_filename: str | None
    clinical_note: str | None
    predictions: list[DiseasePrediction]   # [{label, probability}, ...] x14
    gradcam_summary: str | None            # plain-language Grad-CAM description
    gradcam_image_base64: str | None       # optional heatmap overlay
    model_version: str | None
    inference_timestamp: datetime | None
```

**To plug in the real model once it's handed off:**

1. In `app/module_c_client.py`, implement a class that subclasses
   `ModuleCClient` and wraps the real inference pipeline (image + optional
   clinical note in → `ModuleCDiagnosisInput` out).
2. Change `get_module_c_client()` in that same file to return an instance of
   the real class instead of `MockModuleCClient`.
3. That's it — `/reports/generate` already accepts this exact shape
   directly (if Module C is exposed as its own service, it can just POST to
   `/reports/generate`), and `/reports/demo-generate` will automatically use
   the real model instead of the mock.

No other file needs to change.

## Configuration reference

See `.env.example` for the full list. The important ones:

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | Postgres connection string (or `sqlite:///./dev.db` for local dev) |
| `JWT_SECRET_KEY` | Signs access tokens — generate with `openssl rand -hex 32` |
| `GEMINI_API_KEY` | From [aistudio.google.com/apikey](https://aistudio.google.com/apikey). Leave empty to use the offline fallback template |
| `GEMINI_MODEL` | Defaults to `gemini-2.5-flash`; check [ai.google.dev/gemini-api/docs/models](https://ai.google.dev/gemini-api/docs/models) for the current list |
| `SEED_ADMIN_USERNAME` / `SEED_ADMIN_PASSWORD` | Auto-created account on first boot |

## Deployment (Railway)

1. Push this repo to GitHub.
2. In Railway: **New Project → Deploy from GitHub repo**, pick this repo.
   Railway detects `railway.json` and builds from the `Dockerfile`
   automatically.
3. Add a **PostgreSQL** plugin in the same Railway project — Railway injects
   `DATABASE_URL` automatically (Module D normalizes Railway's
   `postgres://` scheme to the driver-qualified form it needs, see
   `app/database.py`).
4. Set the remaining env vars from `.env.example` in Railway's Variables tab
   (`JWT_SECRET_KEY`, `GEMINI_API_KEY`, `SEED_ADMIN_*`, etc).
5. For automated deploys via GitHub Actions (`.github/workflows/ci-cd.yml`),
   add a `RAILWAY_TOKEN` repo secret (Railway dashboard → Project Settings →
   Tokens) and update the `--service` name in the workflow to match your
   Railway service name.

## Project layout

```
app/
  main.py              FastAPI app, middleware, startup (table creation + seed admin)
  config.py            Settings loaded from env vars
  database.py          SQLAlchemy engine/session
  models.py            ORM models: User, DiagnosisReport (the audit log table)
  schemas.py           Pydantic schemas incl. the Module C contract
  auth.py              Password hashing, JWT issue/verify, get_current_user
  crud.py              DB read/write helpers
  report_generator.py  LangChain + Gemini chain, with offline fallback template
  module_c_client.py   Module C integration point (mock today, swap-in point for the real model)
  routers/
    auth.py            /auth/register, /auth/login
    reports.py          /reports/generate, /reports/demo-generate, /reports/{id}, /reports/
    health.py           /health
tests/                 pytest suite (11 tests), isolated SQLite, no external calls
Dockerfile
docker-compose.yml      Postgres + API for local dev
railway.json             Railway build/deploy config
.github/workflows/ci-cd.yml   Test on every push/PR, deploy to Railway on main
```

## Notes / honest limitations

- **Audit logging** currently stores full prediction payloads, the generated
  report, who generated it, and when — sufficient for the "audit compliance"
  goal on the pitch deck. It does not yet track edits/sign-off by a
  radiologist after generation; that'd be a natural next endpoint
  (`PATCH /reports/{id}/review`) if the project continues.
- **Migrations:** the app uses `Base.metadata.create_all()` on startup rather
  than Alembic migrations, which is simpler for a project at this stage but
  won't handle schema changes on an existing database gracefully. Worth
  adding Alembic if this goes further.
- **Module C integration is mocked** until the real model is handed off —
  see "Connecting the real Module C" above.
