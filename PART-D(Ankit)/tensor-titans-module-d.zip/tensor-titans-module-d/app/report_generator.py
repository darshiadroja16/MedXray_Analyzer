"""
"LangChain + Gemini Report" stage of the deployment pipeline.

If GEMINI_API_KEY is configured, this builds a LangChain chain around
ChatGoogleGenerativeAI and asks it to write a structured radiology report
from the Module C diagnosis payload.

If no key is configured (e.g. a teammate running this locally without one
yet), it falls back to a deterministic, rule-based template. This means the
API, the audit log, and the auth layer all still work end-to-end without a
live Gemini key - useful for local dev, CI, and demos.
"""
import logging
import os

from app.config import get_settings
from app.schemas import ModuleCDiagnosisInput

logger = logging.getLogger("tensor_titans.report_generator")
settings = get_settings()

SYSTEM_PROMPT = """You are an AI assistant that drafts structured chest X-ray radiology reports \
for a radiologist to review. You are a decision-support aid, not a diagnostic authority.

Write in standard radiology report format with these sections, using plain text and clear \
headings (no markdown symbols):

CLINICAL HISTORY
FINDINGS
IMPRESSION
RECOMMENDATION

Rules:
- Base the report ONLY on the data provided below. Never invent findings, patient history, or \
demographics that were not given.
- Reference the confidence/probability of the top findings explicitly.
- Mention the Grad-CAM region if provided, as supporting evidence for the primary finding.
- Keep it concise: 120-220 words total.
- ALWAYS end with this exact line on its own: \
"This report was AI-generated and requires review and sign-off by a licensed radiologist."
"""

USER_PROMPT_TEMPLATE = """Patient ID: {patient_id}
Study ID: {study_id}
Model version: {model_version}

Clinical note provided by referring clinician:
{clinical_note}

Model predictions (label: probability), sorted highest first:
{predictions_block}

Grad-CAM explainability summary:
{gradcam_summary}

Write the structured radiology report now."""


def _format_predictions(diagnosis: ModuleCDiagnosisInput, top_n: int = 6) -> str:
    ranked = sorted(diagnosis.predictions, key=lambda p: p.probability, reverse=True)[:top_n]
    return "\n".join(f"- {p.label}: {p.probability:.1%}" for p in ranked)


def _build_prompt_values(diagnosis: ModuleCDiagnosisInput) -> dict:
    return {
        "patient_id": diagnosis.patient_id,
        "study_id": diagnosis.study_id or "N/A",
        "model_version": diagnosis.model_version or "N/A",
        "clinical_note": diagnosis.clinical_note or "None provided.",
        "predictions_block": _format_predictions(diagnosis),
        "gradcam_summary": diagnosis.gradcam_summary or "Not available.",
    }


def _fallback_template_report(diagnosis: ModuleCDiagnosisInput) -> str:
    """Rule-based report used when no Gemini API key is configured."""
    top = diagnosis.top_prediction()
    ranked = sorted(diagnosis.predictions, key=lambda p: p.probability, reverse=True)
    secondary = [p for p in ranked[1:4] if p.probability >= 0.2]

    lines = [
        "CLINICAL HISTORY",
        diagnosis.clinical_note.strip() if diagnosis.clinical_note else "No clinical history provided.",
        "",
        "FINDINGS",
        f"The multi-modal model's leading finding is {top.label} "
        f"(confidence {top.probability:.1%}).",
    ]
    if secondary:
        extra = ", ".join(f"{p.label} ({p.probability:.1%})" for p in secondary)
        lines.append(f"Additional lower-confidence findings flagged for review: {extra}.")
    if diagnosis.gradcam_summary:
        lines.append(f"Explainability (Grad-CAM): {diagnosis.gradcam_summary}")
    lines += [
        "",
        "IMPRESSION",
        f"Findings most consistent with {top.label.lower()}, pending radiologist correlation "
        f"with prior imaging and clinical context.",
        "",
        "RECOMMENDATION",
        "Radiologist review and sign-off required before this is used for clinical decision-making. "
        "Correlate with patient history and consider follow-up imaging if clinically indicated.",
        "",
        "This report was AI-generated and requires review and sign-off by a licensed radiologist.",
        "",
        "[Generated via local fallback template - set GEMINI_API_KEY to enable Gemini-authored reports.]",
    ]
    return "\n".join(lines)


class ReportGenerator:
    def __init__(self):
        self._chain = None
        self.using_gemini = bool(settings.GEMINI_API_KEY)

        if self.using_gemini:
            try:
                self._chain = self._build_gemini_chain()
            except Exception:  # pragma: no cover - defensive; falls back below
                logger.exception("Failed to initialize Gemini chain; falling back to template reports.")
                self.using_gemini = False

    def _build_gemini_chain(self):
        # Imported lazily so the package (and tests) work even if
        # langchain-google-genai / google auth libs aren't fully configured.
        from langchain_core.output_parsers import StrOutputParser
        from langchain_core.prompts import ChatPromptTemplate
        from langchain_google_genai import ChatGoogleGenerativeAI

        # Setting the env var (rather than passing api_key=...) keeps this
        # working across langchain-google-genai versions, whose constructor
        # kwarg for the key has changed over time.
        os.environ.setdefault("GOOGLE_API_KEY", settings.GEMINI_API_KEY)

        llm = ChatGoogleGenerativeAI(model=settings.GEMINI_MODEL, temperature=settings.GEMINI_TEMPERATURE)
        prompt = ChatPromptTemplate.from_messages(
            [("system", SYSTEM_PROMPT), ("human", USER_PROMPT_TEMPLATE)]
        )
        return prompt | llm | StrOutputParser()

    def generate(self, diagnosis: ModuleCDiagnosisInput) -> tuple[str, str]:
        """Returns (report_text, source) where source is 'gemini' or 'fallback_template'."""
        if self.using_gemini and self._chain is not None:
            try:
                text = self._chain.invoke(_build_prompt_values(diagnosis))
                return text.strip(), "gemini"
            except Exception:
                logger.exception("Gemini report generation failed; using fallback template for this request.")

        return _fallback_template_report(diagnosis), "fallback_template"


_generator: ReportGenerator | None = None


def get_report_generator() -> ReportGenerator:
    """FastAPI dependency - single shared instance so the Gemini chain isn't rebuilt per request."""
    global _generator
    if _generator is None:
        _generator = ReportGenerator()
    return _generator
