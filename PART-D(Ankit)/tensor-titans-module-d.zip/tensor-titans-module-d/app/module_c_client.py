"""
Module C integration point.

Student C's real pipeline (DenseNet-121 + ClinicalBERT fusion, per their
Module C notes) isn't wired in yet - it'll be handed off later. Rather than
block Module D on that, this file provides a `ModuleCClient` interface plus
a `MockModuleCClient` that returns realistically-shaped output so the rest
of the pipeline (report generation -> audit log -> JWT-gated API) can be
built, demoed and tested today.

HOW TO SWAP IN THE REAL MODEL LATER
------------------------------------
1. Implement a class with the same `predict(...)` signature as
   `ModuleCClient` below, wrapping the actual DenseNet-121 + ClinicalBERT
   fusion model + Grad-CAM code from Module C.
2. Have it return a `ModuleCDiagnosisInput` (see app/schemas.py) - that's
   the whole contract.
3. In app/routers/reports.py, swap `get_module_c_client` to return an
   instance of the real class instead of `MockModuleCClient`.
Nothing else in Module D needs to change.
"""
import random
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Optional

from app.schemas import CHESTXRAY14_LABELS, DiseasePrediction, ModuleCDiagnosisInput


class ModuleCClient(ABC):
    """Interface every Module C backend (real or mock) must implement."""

    @abstractmethod
    def predict(
        self,
        patient_id: str,
        study_id: Optional[str] = None,
        image_filename: Optional[str] = None,
        clinical_note: Optional[str] = None,
    ) -> ModuleCDiagnosisInput:
        raise NotImplementedError


class MockModuleCClient(ModuleCClient):
    """
    Deterministic-ish mock so demos are reproducible: seeding on patient_id
    means the same patient always gets the same fake result, which is much
    less confusing when showing this off live.
    """

    def predict(
        self,
        patient_id: str,
        study_id: Optional[str] = None,
        image_filename: Optional[str] = None,
        clinical_note: Optional[str] = None,
    ) -> ModuleCDiagnosisInput:
        rng = random.Random(patient_id)

        # Make one or two findings clearly dominant, the rest low-probability
        # background noise - this is what a real multi-label classifier's
        # output distribution tends to look like.
        labels = CHESTXRAY14_LABELS.copy()
        rng.shuffle(labels)
        dominant = labels[:2]

        predictions = []
        for label in CHESTXRAY14_LABELS:
            if label in dominant:
                prob = round(rng.uniform(0.55, 0.93), 4)
            else:
                prob = round(rng.uniform(0.01, 0.25), 4)
            predictions.append(DiseasePrediction(label=label, probability=prob))

        top_label = max(predictions, key=lambda p: p.probability).label
        gradcam_region = rng.choice(
            ["right lower lobe", "left upper lobe", "right hilar region", "bilateral lower zones", "left mid-lung field"]
        )

        return ModuleCDiagnosisInput(
            patient_id=patient_id,
            study_id=study_id or f"STUDY-{rng.randint(10000, 99999)}",
            image_filename=image_filename,
            clinical_note=clinical_note,
            predictions=predictions,
            gradcam_summary=f"Grad-CAM activation concentrated in the {gradcam_region}, "
            f"consistent with the predicted {top_label.lower()} finding.",
            gradcam_image_base64=None,
            model_version="densenet121-clinicalbert-fusion-v1-MOCK",
            inference_timestamp=datetime.now(timezone.utc),
        )


def get_module_c_client() -> ModuleCClient:
    """FastAPI dependency. Swap this to the real client once Module C lands."""
    return MockModuleCClient()
