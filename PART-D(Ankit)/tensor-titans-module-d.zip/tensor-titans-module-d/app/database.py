"""
SQLAlchemy engine + session handling.

Works with:
  - local docker-compose Postgres
  - a managed Postgres URL Railway (or any host) injects as DATABASE_URL
  - a sqlite:// URL, which the test suite swaps in via dependency override

Railway / Heroku-style hosts often hand you a bare "postgres://" or
"postgresql://" URL with no driver specified. SQLAlchemy needs the psycopg2
driver named explicitly, so we normalize that here rather than asking every
teammate to remember it.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from app.config import get_settings

settings = get_settings()


def _normalize_db_url(url: str) -> str:
    if url.startswith("postgres://"):
        return url.replace("postgres://", "postgresql+psycopg2://", 1)
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+psycopg2://", 1)
    return url


DATABASE_URL = _normalize_db_url(settings.DATABASE_URL)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db():
    """FastAPI dependency - yields a DB session and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
