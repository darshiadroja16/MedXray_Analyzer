import os

# Force a throwaway SQLite DB and no Gemini key *before* app.config is
# imported anywhere, so the test suite never touches Postgres or the real
# Gemini API - it exercises the fallback template path instead.
os.environ["DATABASE_URL"] = "sqlite:///./test_tensor_titans.db"
os.environ["GEMINI_API_KEY"] = ""
os.environ["JWT_SECRET_KEY"] = "test-secret"
os.environ["SEED_ADMIN_USERNAME"] = "admin"
os.environ["SEED_ADMIN_PASSWORD"] = "admin123"

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base, get_db
from app.main import app

TEST_DB_URL = "sqlite:///./test_tensor_titans.db"
engine = create_engine(TEST_DB_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(scope="session", autouse=True)
def _setup_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)
    if os.path.exists("./test_tensor_titans.db"):
        os.remove("./test_tensor_titans.db")


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture
def auth_headers(client):
    """Registers a fresh user and returns an Authorization header for it."""
    client.post(
        "/auth/register",
        json={
            "username": "dr_house",
            "email": "house@ppth.example",
            "password": "vicodin123",
            "full_name": "Dr. Gregory House",
        },
    )
    resp = client.post(
        "/auth/login",
        data={"username": "dr_house", "password": "vicodin123"},
    )
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}
