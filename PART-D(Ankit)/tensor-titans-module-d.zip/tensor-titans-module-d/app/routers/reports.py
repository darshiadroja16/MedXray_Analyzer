from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app import crud
from app.auth import get_current_user
from app.database import get_db
from app.models import User
from app.module_c_client import ModuleCClient, get_module_c_client
from app.report_generator import ReportGenerator, get_report_generator
from app.schemas import GeneratedReportResponse, ModuleCDiagnosisInput, ReportListItem

router = APIRouter(prefix="/reports", tags=["reports"])


def _persist_and_respond(
    db: Session,
    diagnosis: ModuleCDiagnosisInput,
    generator: ReportGenerator,
    current_user: User,
) -> GeneratedReportResponse:
    report_text, source = generator.generate(diagnosis)
    record = crud.save_diagnosis_report(
        db,
        diagnosis=diagnosis,
        generated_report=report_text,
        report_source=source,
        created_by_id=current_user.id,
    )
    return GeneratedReportResponse(
        id=record.id,
        patient_id=record.patient_id,
        study_id=record.study_id,
        top_label=record.top_label,
        top_probability=record.top_probability,
        model_version=record.model_version,
        generated_report=record.generated_report,
        report_source=record.report_source,
        created_by=current_user.username,
        created_at=record.created_at,
    )


@router.post("/generate", response_model=GeneratedReportResponse, status_code=status.HTTP_201_CREATED)
def generate_report(
    diagnosis: ModuleCDiagnosisInput,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    generator: ReportGenerator = Depends(get_report_generator),
):
    """
    Main integration endpoint: Module C (or whoever calls this - see
    ModuleCDiagnosisInput in app/schemas.py for the exact contract) posts a
    diagnosis payload here. Module D turns it into a structured report via
    LangChain + Gemini and permanently audit-logs the result to Postgres.
    """
    return _persist_and_respond(db, diagnosis, generator, current_user)


@router.post("/demo-generate/{patient_id}", response_model=GeneratedReportResponse, status_code=status.HTTP_201_CREATED)
def generate_demo_report(
    patient_id: str,
    clinical_note: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    generator: ReportGenerator = Depends(get_report_generator),
    module_c: ModuleCClient = Depends(get_module_c_client),
):
    """
    End-to-end demo path that doesn't require Module C's real model yet:
    runs the mock Module C client, then the same generate -> audit-log flow
    as /reports/generate. Delete or repoint this once the real model lands.
    """
    diagnosis = module_c.predict(patient_id=patient_id, clinical_note=clinical_note)
    return _persist_and_respond(db, diagnosis, generator, current_user)


@router.get("/{report_id}", response_model=GeneratedReportResponse)
def read_report(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    record = crud.get_report(db, report_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found")
    return GeneratedReportResponse(
        id=record.id,
        patient_id=record.patient_id,
        study_id=record.study_id,
        top_label=record.top_label,
        top_probability=record.top_probability,
        model_version=record.model_version,
        generated_report=record.generated_report,
        report_source=record.report_source,
        created_by=record.created_by.username if record.created_by else None,
        created_at=record.created_at,
    )


@router.get("/", response_model=list[ReportListItem])
def list_reports(
    patient_id: Optional[str] = Query(default=None),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=50, ge=1, le=200),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """The audit log view: every report ever generated, newest first."""
    return crud.list_reports(db, patient_id=patient_id, skip=skip, limit=limit)
