import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import crud
from app.config import get_settings
from app.database import Base, SessionLocal, engine
from app.routers import auth, health, reports

logging.basicConfig(level=logging.INFO)
settings = get_settings()


@asynccontextmanager
async def lifespan(_: FastAPI):
    # For a student project, create_all is simpler and more reliable than
    # wiring up Alembic migrations in every environment. If this grows into
    # something longer-lived, swap this for real migrations.
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        crud.ensure_seed_admin(
            db,
            username=settings.SEED_ADMIN_USERNAME,
            email=settings.SEED_ADMIN_EMAIL,
            password=settings.SEED_ADMIN_PASSWORD,
        )
    finally:
        db.close()

    yield  # app runs here


app = FastAPI(
    title=settings.APP_NAME,
    description=(
        "Tensor Titans - Module D: AI Report Generation & Production Deployment.\n\n"
        "Takes a Module C diagnosis payload, turns it into a structured radiology "
        "report with LangChain + Gemini, and permanently audit-logs the result to "
        "PostgreSQL behind JWT authentication."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(auth.router)
app.include_router(reports.router)


@app.get("/")
def root():
    return {
        "service": settings.APP_NAME,
        "docs": "/docs",
        "health": "/health",
    }
