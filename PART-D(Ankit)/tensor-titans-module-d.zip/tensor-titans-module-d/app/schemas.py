"""
Pydantic schemas.

`ModuleCDiagnosisInput` is the important one for the team: it's the contract
Module D expects to receive once Student C's real inference pipeline is
wired in. Whoever connects Module C just needs to produce JSON matching this
shape (see module_c_client.py for a mock that already does this).
"""
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field, field_validator

# The 14 NIH ChestX-ray14 pathology labels Module C's classifier predicts over.
CHESTXRAY14_LABELS = [
    "Atelectasis", "Cardiomegaly", "Effusion", "Infiltration", "Mass",
    "Nodule", "Pneumonia", "Pneumothorax", "Consolidation", "Edema",
    "Emphysema", "Fibrosis", "Pleural_Thickening", "Hernia",
]


# ---------------------------------------------------------------------------
# Module C -> Module D contract
# ---------------------------------------------------------------------------
class DiseasePrediction(BaseModel):
    label: str
    probability: float = Field(ge=0.0, le=1.0)


class ModuleCDiagnosisInput(BaseModel):
    """
    Exactly what Module D needs from Module C (+ upstream image metadata) to
    generate and audit-log a report. This is the integration boundary -
    Module C's real model just needs to return this shape instead of the
    mock in module_c_client.py.
    """

    patient_id: str
    study_id: Optional[str] = None
    image_filename: Optional[str] = None

    clinical_note: Optional[str] = Field(
        default=None, description="Free-text clinical note supplied alongside the X-ray, if any."
    )

    predictions: list[DiseasePrediction] = Field(
        description="Multi-label probabilities across the 14 ChestX-ray14 pathologies."
    )

    gradcam_summary: Optional[str] = Field(
        default=None,
        description="Plain-language description of the Grad-CAM heatmap region, "
        "e.g. 'high activation in the right lower lobe'.",
    )
    gradcam_image_base64: Optional[str] = Field(
        default=None, description="Optional base64-encoded Grad-CAM heatmap overlay."
    )

    model_version: Optional[str] = "densenet121-clinicalbert-fusion-v1"
    inference_timestamp: Optional[datetime] = None

    @field_validator("predictions")
    @classmethod
    def must_have_predictions(cls, v: list[DiseasePrediction]) -> list[DiseasePrediction]:
        if not v:
            raise ValueError("predictions cannot be empty")
        return v

    def top_prediction(self) -> DiseasePrediction:
        return max(self.predictions, key=lambda p: p.probability)


# ---------------------------------------------------------------------------
# Report generation response
# ---------------------------------------------------------------------------
class GeneratedReportResponse(BaseModel):
    id: str
    patient_id: str
    study_id: Optional[str] = None
    top_label: Optional[str] = None
    top_probability: Optional[float] = None
    model_version: Optional[str] = None
    generated_report: str
    report_source: str
    created_by: Optional[str] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class ReportListItem(BaseModel):
    id: str
    patient_id: str
    study_id: Optional[str] = None
    top_label: Optional[str] = None
    top_probability: Optional[float] = None
    report_source: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    email: str
    password: str = Field(min_length=6)
    full_name: str = ""
    role: str = "radiologist"


class UserOut(BaseModel):
    id: str
    username: str
    email: str
    full_name: str
    role: str
    created_at: datetime

    model_config = {"from_attributes": True}


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenPayload(BaseModel):
    sub: Optional[str] = None
    exp: Optional[int] = None
