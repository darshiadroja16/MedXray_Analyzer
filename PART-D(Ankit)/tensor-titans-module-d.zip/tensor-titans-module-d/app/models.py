import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, DateTime, Float, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    """A radiologist / clinician account. JWT tokens are issued for these."""

    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(255), default="")
    hashed_password: Mapped[str] = mapped_column(String, nullable=False)
    role: Mapped[str] = mapped_column(String(32), default="radiologist")
    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    reports: Mapped[list["DiagnosisReport"]] = relationship(back_populates="created_by")


class DiagnosisReport(Base):
    """
    One row per report generated from a Module C diagnosis payload.

    This table doubles as the audit log required by the deployment pipeline:
    every prediction that ever gets turned into a report is permanently
    recorded here with who generated it and when, regardless of whether the
    caller later does anything else with the result.
    """

    __tablename__ = "diagnosis_reports"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)

    # Identifiers coming from upstream (Module A/B/C)
    patient_id: Mapped[str] = mapped_column(String(128), index=True, nullable=False)
    study_id: Mapped[str] = mapped_column(String(128), nullable=True)
    image_filename: Mapped[str] = mapped_column(String(255), nullable=True)
    model_version: Mapped[str] = mapped_column(String(128), nullable=True)

    # Raw Module C payload, kept verbatim for auditability / reproducibility
    predictions_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    clinical_note: Mapped[str] = mapped_column(Text, nullable=True)
    gradcam_summary: Mapped[str] = mapped_column(Text, nullable=True)

    # Denormalized top finding, so the audit log can be scanned/filtered fast
    top_label: Mapped[str] = mapped_column(String(128), nullable=True)
    top_probability: Mapped[float] = mapped_column(Float, nullable=True)

    # LLM output
    generated_report: Mapped[str] = mapped_column(Text, nullable=False)
    report_source: Mapped[str] = mapped_column(String(32), default="gemini")  # "gemini" | "fallback_template"

    # Audit trail
    created_by_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_by: Mapped["User"] = relationship(back_populates="reports")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
