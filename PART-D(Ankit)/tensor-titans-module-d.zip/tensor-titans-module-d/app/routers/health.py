from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app.report_generator import get_report_generator

router = APIRouter(tags=["health"])
settings = get_settings()


@router.get("/health")
def health(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False

    generator = get_report_generator()

    return {
        "status": "ok" if db_ok else "degraded",
        "database": "up" if db_ok else "down",
        "report_engine": "gemini" if generator.using_gemini else "fallback_template",
        "environment": settings.ENVIRONMENT,
    }
