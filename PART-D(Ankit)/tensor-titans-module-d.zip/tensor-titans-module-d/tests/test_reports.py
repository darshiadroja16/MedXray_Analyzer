SAMPLE_DIAGNOSIS = {
    "patient_id": "PT-0001",
    "study_id": "STUDY-42",
    "image_filename": "pt0001_cxr.png",
    "clinical_note": "58-year-old male, productive cough and fever for 4 days.",
    "predictions": [
        {"label": "Pneumonia", "probability": 0.87},
        {"label": "Infiltration", "probability": 0.41},
        {"label": "Effusion", "probability": 0.12},
        {"label": "Cardiomegaly", "probability": 0.05},
    ],
    "gradcam_summary": "High activation in the right lower lobe.",
    "model_version": "densenet121-clinicalbert-fusion-v1",
}


def test_generate_report_from_module_c_payload(client, auth_headers):
    resp = client.post("/reports/generate", json=SAMPLE_DIAGNOSIS, headers=auth_headers)
    assert resp.status_code == 201
    body = resp.json()

    assert body["patient_id"] == "PT-0001"
    assert body["top_label"] == "Pneumonia"
    assert body["top_probability"] == 0.87
    # No GEMINI_API_KEY is set in tests, so this must use the fallback path.
    assert body["report_source"] == "fallback_template"
    assert "radiologist" in body["generated_report"].lower()


def test_generated_report_is_audit_logged_and_retrievable(client, auth_headers):
    create_resp = client.post("/reports/generate", json=SAMPLE_DIAGNOSIS, headers=auth_headers)
    report_id = create_resp.json()["id"]

    get_resp = client.get(f"/reports/{report_id}", headers=auth_headers)
    assert get_resp.status_code == 200
    assert get_resp.json()["id"] == report_id

    list_resp = client.get("/reports/", headers=auth_headers)
    assert list_resp.status_code == 200
    assert any(r["id"] == report_id for r in list_resp.json())


def test_demo_generate_uses_mock_module_c(client, auth_headers):
    resp = client.post("/reports/demo-generate/PT-DEMO-1", headers=auth_headers)
    assert resp.status_code == 201
    body = resp.json()
    assert body["patient_id"] == "PT-DEMO-1"
    assert body["top_label"] is not None


def test_empty_predictions_rejected(client, auth_headers):
    bad_payload = dict(SAMPLE_DIAGNOSIS, predictions=[])
    resp = client.post("/reports/generate", json=bad_payload, headers=auth_headers)
    assert resp.status_code == 422


def test_reports_require_auth(client):
    resp = client.post("/reports/generate", json=SAMPLE_DIAGNOSIS)
    assert resp.status_code == 401
